/*--------------DESCRIPTION OF FUNCTIONS-----------------------
The SimpleStat is currently configured to perform one of the routines below under the control of the PC.  If only a DPV measurement is required,
the code in DPV_Sweep() should be moved to main() and the remaider of the code below can be removed.  As soon as the battery is intserted,
DPV sweeps will start and continue until power is removed.  This approach is useful for users who have a robust measurement system and only
want to use the on/off lights to indicate the status of the sample.
*/


#include <atmel_start.h>
#include <util/delay.h>
#include <stdio.h> //required for printf function
#include <avr/interrupt.h>
#include <avr/sleep.h>

extern bool dataReceived; 
void connect_cell(){
	
	PA0_set_level(true);
	PA1_set_level(true);
}

void disconnect_cell(){
	
	PA0_set_level(false);
	PA1_set_level(false);
}


uint32_t ADC_average_conversion(adc_0_channel_t channel)
{
adc_result_t res =0;
uint32_t total = 0;
uint32_t average = 0;
uint8_t i =0;
uint8_t window = 20;

for (i = 0; i < window; i++)
{
	//code here to enter sleep mode
	res = ADC_0_get_conversion(channel);
	total = total+ res;
}

average = total/window;
return average;
}


//Set simplestat to middle DAC output, followed by min DAC output, followed by max output.
//Allows user to record max and min potentials to calibrate the instrument.
void calibration(){
	uint16_t calValue = 2048;
	
	//printString("Enter number to set cell to midpoint value.  Once complete, enter 0 to move to next stage.\n");
	connect_cell();
	
	//while(1){
		//DAC_0_set_output(1000);
		//_delay_ms(1);
		//DAC_0_set_output(1137);
		//_delay_ms(1);
		//
	//}
	
	while (calValue!=0)	//stay in while loop until user indicates move to next stage by entering zero.
	{
			//while(dataReceived==false){TEST_PA7_set_level(true);} //Wait for user to enter DAC number or press a key. Action in while loop to be replaced with a non-operation.
			calValue = getNumber();	
			//dataReceived = false;

			DAC_0_set_output(calValue);
			printWord(ADC_average_conversion(11));
			printString("\n");
	}
	//printString("DAC output set to 0, note potential between WE and CE then press any key.");
	calValue = getNumber(); // this is used to hold the script and wait for any key, whilst also clearing the receive buffer.
	DAC_0_set_output(4095);
	//printString("DAC output set to 4095, note potential between WE and CE then press any key.");
	calValue=getNumber();
	
	disconnect_cell();
		
	
}

//Perform a DPV sweep the number of time defined in the DPV_REPS directive.
void DPV_Sweep(){
	
	//Get DPV parameters from VB interface:
	uint16_t REF_HIGH;				//Starting point for the sweep in DAC units
	uint16_t REF_LOW;				//End reference point for the sweep in DAC units
	uint16_t REF_INCREMENT;			//Step increase in potential between pulses
	uint16_t PULSE;					//Amplitude of each pulse
	uint16_t QUIET_TIME;			//Quiet time between pulses in ms
	uint16_t PULSE_TIME;			//Pulse time in ms
	uint8_t DPV_REPS;
	
	printString("d"); //printString("\nNOTE: Provide all values in DAC units.\nProvide Ref High:");
	REF_HIGH = getNumber();				//Receive REF_HIGH
	//printString("\nProvide Ref Low:");
	REF_LOW = getNumber();				//Receive REF_LOW
	//printString("\nProvide Increment:");
	REF_INCREMENT= getNumber();			//Receive REF_INCREMENT
	//printString("\nProvide Pulse:");	
	PULSE = getNumber();				//Receive PULSE
	//printString("\nQuiet Time (ms):");
	QUIET_TIME = getNumber();			//Receive QUIET_TIME
	//printString("\nPulse Time (ms):");	
	PULSE_TIME = getNumber();			//Receive PULSE_TIME
	//printString("\n Number of reps:");	
	DPV_REPS = getNumber();				//Receive DPV_REP

	uint16_t PULSE_NO = (REF_HIGH - REF_LOW)/REF_INCREMENT;
	uint16_t REF = 0;
	uint16_t i = 0;
	uint16_t j = 0;
	uint16_t k = 0;
	adc_result_t QUIET_CURR;
	adc_result_t PEAK_CURR;
	
	_delay_ms(1000);
	
	//Print output to UART terminal.
	printString("Start: ");
	printWord(REF_LOW);
	printString(" | End: ");
	printWord(REF_HIGH);
	printString(" | Inc: ");
	printWord(REF_INCREMENT);
	printString(" | Pulse: ");
	printWord(PULSE);
	printString(" | QT: ");
	printWord(QUIET_TIME);
	printString(" | PT: ");
	printWord(PULSE_TIME);
	printString(" | Reps: ");
	printWord(DPV_REPS);
	printString("\n");
	
	_delay_ms(1000);
	
	printString("START\n");
	connect_cell();
	//Loop through DPV script the number of times defined in DPV_REPS to capture data
	for (j=0; j<DPV_REPS; j++)
	{
		REF = REF_LOW;
		DAC_0_set_output(REF);
		//_delay_ms(1000);
		
		//Perform the steps and pulses required for each sweep.
		for (i=0;i<=PULSE_NO;i++) {
			
			for (k=0;k<=QUIET_TIME;k++)
			{
				_delay_ms(1);
			}
			
			QUIET_CURR = ADC_average_conversion(11);
			DAC_0_set_output(REF+PULSE);
			
			for (k=0;k<=PULSE_TIME;k++)
			{
				_delay_ms(1);
			}
			
			PEAK_CURR = ADC_average_conversion(11);
			REF = REF+REF_INCREMENT;
			DAC_0_set_output(REF);
			printWord(REF-REF_INCREMENT);
			printString("\t");
			printWord(QUIET_CURR);
			printString("\t");
			printWord(PEAK_CURR);
			printString("\t");
			printWord(PEAK_CURR-QUIET_CURR);
			printString("\n");
			

		}
	}
	disconnect_cell();
	printString("END\n");
}
//Sweep from positive potential to negative
void LSV_sweep_down(uint16_t REF_HIGH, uint16_t REF_LOW, uint16_t MS_PER_STEP){
	uint16_t i;
	uint16_t j;
	adc_result_t CURRENT;
	
	//Perform the steps and pulses required for each sweep.
	for (i=REF_HIGH;i>=REF_LOW;i--) {
		DAC_0_set_output(i);
		for (j=0;j<=MS_PER_STEP;j++)
		{
			_delay_ms(1);
		}
		CURRENT = ADC_average_conversion(11); //ALSO NEED TO CHANGE SWEEP DOWN -  CURRENTLY USING THIS AS A TEST
		printWord(i);
		printString("\t");
		printWord(CURRENT);
		printString("\n");
	}

}

//sweep from negative potential to positive
void LSV_sweep_up(uint16_t REF_HIGH, uint16_t REF_LOW, uint16_t MS_PER_STEP){
	uint16_t i;
	uint16_t j;
	adc_result_t CURRENT;
	
	//Perform the steps and pulses required for each sweep.
	for (i=REF_LOW;i<=REF_HIGH;i++) {
		DAC_0_set_output(i);
		for (j=0;j<=MS_PER_STEP;j++)
		{
			_delay_ms(1);
		}
		CURRENT = ADC_average_conversion(11);
		printWord(i);
		printString("\t");
		printWord(CURRENT);
		printString("\n");
	}
}

//Perform LSV Sweep
void LSV_sweep(){
	//Get DPV parameters from VB interface:
	uint16_t REF_HIGH;				//Starting point for the sweep in DAC units
	uint16_t REF_LOW;				//End reference point for the sweep in DAC units
	uint16_t MS_PER_STEP;			//Pause required between each step
	uint16_t LSV_REPS;
	uint16_t SWEEP_UP;
	uint16_t k = 0;
	//_delay_ms(1000);
	printString("l\n");
	//printString("\nNOTE: Provide all values in DAC units.\nProvide Ref High: ");
	REF_HIGH = getNumber();				//Receive REF_HIGH
	//printString("\nProvide Ref Low: ");
	REF_LOW = getNumber();				//Receive REF_LOW
	//printString("Provide time per step (ms): ");
	MS_PER_STEP= getNumber();			//Receive MS_PER_STEP
	//printString("Provide number of reps: ");
	LSV_REPS = getNumber();				//Receive LSV_REPS
	//printString("Sweep up = 1; sweep down = 0: ");
	SWEEP_UP = getNumber();				//Receive SWEEP_UP
	

	
	//Print output to UART terminal.
	printString("\nStart: ");
	printWord(REF_HIGH);
	printString(" | End: ");
	printWord(REF_LOW);
	printString(" | ms/DAC unit: ");
	printWord(MS_PER_STEP);
	printString(" | Reps: ");
	printWord(LSV_REPS);
	printString("\n");
	
	_delay_ms(1000);
	
	printString("START\n");
	connect_cell();
	//Loop through DPV script the number of times defined in DPV_REPS to capture data
	for (k=0; k<LSV_REPS; k++)
	{
		if (SWEEP_UP==1)
		{
			LSV_sweep_up(REF_HIGH, REF_LOW, MS_PER_STEP);
		}
		else
		{
			LSV_sweep_down(REF_HIGH, REF_LOW, MS_PER_STEP);
		}
		
	}
	disconnect_cell();
	printString("END\n");
}

//Perform a CV sweep
void CV_sweep(){
	//Get CV parameters from VB interface:
	uint16_t REF_LOW;				//Starting point for the sweep in DAC units
	uint16_t REF_HIGH;				//End reference point for the sweep in DAC units
	uint16_t MS_PER_STEP;			//Pause required between each step
	uint16_t CV_REPS;
	uint16_t SWEEP_UP;
	uint16_t k = 0;
	
	printString("v\n"); 
	//printString(" NOTE: Provide all values in DAC units.\nProvide Ref High:");
	
	REF_LOW = getNumber();				//Receive REF_LOW
	//printString("Provide Ref Low:");
	REF_HIGH = getNumber();				//Receive REF_HIGH
	//printString("Provide time per step (ms):");
	MS_PER_STEP= getNumber();			//Receive MS_PER_STEP
	//printString("Provide number of reps:");
	CV_REPS = getNumber();				//Receive CV_REPS
	//printString("Sweep up = 1; sweep down = 0:");
	SWEEP_UP = getNumber();				//Receive SWEEP_UP
	
	_delay_ms(1000);
	
	//Print output to UART terminal.
	printString("REF_HIGH 1: ");
	printWord(REF_HIGH);
	printString(" | REF_LOW 2: ");
	printWord(REF_LOW);
	printString(" | ms/DAC unit: ");
	printWord(MS_PER_STEP);
	printString(" | Reps: ");
	printWord(CV_REPS);
	printString("\n");
	
	_delay_ms(1000);
	
	printString("START\n");
	connect_cell();
	//Loop through CV script the number of times defined in CV_REPS to capture data
	for (k=0; k<CV_REPS; k++)
	{
		if (SWEEP_UP==1)
		{
			LSV_sweep_up(REF_HIGH, REF_LOW, MS_PER_STEP);
			LSV_sweep_down(REF_HIGH, REF_LOW, MS_PER_STEP);
		}
		else
		{
			LSV_sweep_down(REF_HIGH, REF_LOW, MS_PER_STEP);
			LSV_sweep_up(REF_HIGH, REF_LOW, MS_PER_STEP);
		}
		
	}
	disconnect_cell();
	printString("END\n");

}