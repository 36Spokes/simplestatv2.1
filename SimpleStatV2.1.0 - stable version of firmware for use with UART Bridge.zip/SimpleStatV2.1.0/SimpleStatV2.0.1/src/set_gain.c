/*
* set_gain.c
*
* Created: 05/05/2020 16:02:56
*  Author: vib10128
*/

#include <atmel_start.h>

/*---Define resistor values used in circuit---*/

#define R1 "470 Ohms"
#define R2 "2 kOhms"
#define R3 "4.7 kOhms"
#define R4 "10 kOhms"
#define R5 "20 kOhms"
#define R6 "47 kOhms"
#define R7 "200 kOhms"
#define R8 "470 kOhms"



void set_gain_R1(){
	
	PD1_set_level(false);
	PD2_set_level(false);
	PD3_set_level(false);
}

void set_gain_R2(){
	PD1_set_level(true);
	PD2_set_level(false);
	PD3_set_level(false);
}

void set_gain_R3(){
	PD1_set_level(false);
	PD2_set_level(true);
	PD3_set_level(false);
}

void set_gain_R4(){
	PD1_set_level(true);
	PD2_set_level(true);
	PD3_set_level(false);
}

void set_gain_R5(){
	PD1_set_level(false);
	PD2_set_level(false);
	PD3_set_level(true);
}

void set_gain_R6(){
	PD1_set_level(true);
	PD2_set_level(false);
	PD3_set_level(true);
}

void set_gain_R7(){
	PD1_set_level(false);
	PD2_set_level(true);
	PD3_set_level(true);
}

void set_gain_R8(){
	PD1_set_level(true);
	PD2_set_level(true);
	PD3_set_level(true);
}

void gain(){
	uint8_t readData;
	//printString("\nSelect gain from following options:\n 1 = R1 (");
	//printString(R1);
	//printString(")\n 2 = R2 (");
	//printString(R2);
	//printString(")\n 3 = R3 (");
	//printString(R3);
	//printString(")\n 4 = R4 (");
	//printString(R4);
	//printString(")\n 5 = R5 (");
	//printString(R5);
	//printString(")\n 6 = R6 (");
	//printString(R6);
	//printString(")\n 7 = R7 (");
	//printString(R7);
	//printString(")\n 8 = R8 (");
	//printString(R8);
	//printString(")\n");
	
	readData = (receiveByte()-48);	//Subtract 48 to get the numerical value from the calculation.
	
	if (readData == 1)
	{
		set_gain_R1();
		//printString("\nGain set to ");
		//printString(R1);
	}
	
	else if (readData == 2)
	{
		set_gain_R2();
		//printString("\nGain set to ");
		//printString(R2);
	}
	
	else if (readData == 3)
	{
		set_gain_R3();
		//printString("\nGain set to ");
		//printString(R3);
	}
	
	else if (readData == 4)
	{
		set_gain_R4();
		//printString("\nGain set to ");
		//printString(R4);
	}
	else if (readData == 5)
	{
		set_gain_R5();
		//printString("\nGain set to ");
		//printString(R5);
	}
	
	else if (readData == 6)
	{
		set_gain_R6();
		//printString("\nGain set to ");
		//printString(R6);
	}
	else if (readData == 7)
	{
		set_gain_R7();
		//printString("\nGain set to ");
		//printString(R7);
	}
	else if (readData == 8)
	{
		set_gain_R8();
		//printString("\nGain set to ");
		//printString(R8);
	}
}