/**
 * \file
 *
 * \brief TC2 related functionality implementation.
 *
 (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms,you may use this software and
    any derivatives exclusively with Microchip products.It is your responsibility
    to comply with third party license terms applicable to your use of third party
    software (including open source software) that may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 */

/**
 * \defgroup doc_driver_adc_init TC2 Init Driver
 * \ingroup doc_driver_tc2
 *
 * \section doc_driver_tc2_rev Revision History
 * - v0.0.0.1 Initial Commit
 *
 *@{
 */
#include <tc2.h>

/**
 * \brief Initialize tc2 interface
 * \return Initialization status.
 */
int8_t TIMER_0_init()
{

	TCC2.CTRLE = TC2_BYTEM_SPLITMODE_gc; /* Timer/Counter split into two 8-bit Counters (TC2) */

	// TCC2.CTRLB = 0 << TC2_HCMPDEN_bp /* High Byte CompareD Enable: disabled */
	//		 | 0 << TC2_HCMPCEN_bp /* High Byte CompareC Enable: disabled */
	//		 | 0 << TC2_HCMPBEN_bp /* High Byte CompareB Enable: disabled */
	//		 | 0 << TC2_HCMPAEN_bp /* High Byte CompareA Enable: disabled */
	//		 | 0 << TC2_LCMPDEN_bp /* Low Byte Compare D Enable: disabled */
	//		 | 0 << TC2_LCMPCEN_bp /* Low Byte Compare C Enable: disabled */
	//		 | 0 << TC2_LCMPBEN_bp /* Low Byte Compare B Enable: disabled */
	//		 | 0 << TC2_LCMPAEN_bp; /* Low Byte Compare A Enable: disabled */

	// TCC2.CTRLC = 0 << TC2_HCMPD_bp /* High Byte Compare D Waveform Output Value: disabled */
	//		 | 0 << TC2_HCMPC_bp /* High Byte Compare C Waveform Output Value: disabled */
	//		 | 0 << TC2_HCMPB_bp /* High Byte Compare B Waveform Output Value: disabled */
	//		 | 0 << TC2_HCMPA_bp /* High Byte Compare A Waveform Output Value: disabled */
	//		 | 0 << TC2_LCMPD_bp /* Low Byte Compare D Waveform Output Value: disabled */
	//		 | 0 << TC2_LCMPC_bp /* Low Byte Compare C Waveform Output Value: disabled */
	//		 | 0 << TC2_LCMPB_bp /* Low Byte Compare B Waveform Output Value: disabled */
	//		 | 0 << TC2_LCMPA_bp; /* Low Byte Compare A Waveform Output Value: disabled */

	// TCC2.INTCTRLA = TC2_HUNFINTLVL_OFF_gc /* Interrupt Disabled */
	//		 | TC2_LUNFINTLVL_OFF_gc; /* Interrupt Disabled */

	// TCC2.INTCTRLB = TC2_LCMPDINTLVL_OFF_gc /* Interrupt Disabled */
	//		 | TC2_LCMPCINTLVL_OFF_gc /* Interrupt Disabled */
	//		 | TC2_LCMPBINTLVL_OFF_gc /* Interrupt Disabled */
	//		 | TC2_LCMPAINTLVL_OFF_gc; /* Interrupt Disabled */

	// TCC2.LCNT = 0; /* Low Byte Count: 0 */

	// TCC2.HCNT = 0; /* High Byte Count: 0 */

	// TCC2.LPER = 255; /* Low Byte Period: 255 */

	// TCC2.HPER = 255; /* High Byte Period: 255 */

	// TCC2.LCMPA = 0; /* Low Byte Compare A: 0 */

	// TCC2.HCMPA = 0; /* High Byte Compare A: 0 */

	// TCC2.LCMPB = 0; /* Low Byte Compare B: 0 */

	// TCC2.HCMPB = 0; /* High Byte Compare B: 0 */

	// TCC2.LCMPC = 0; /* Low Byte Compare C: 0 */

	// TCC2.HCMPC = 0; /* High Byte Compare C: 0 */

	// TCC2.LCMPD = 0; /* Low Byte Compare D: 0 */

	// TCC2.HCMPD = 0; /* High Byte Compare D: 0 */

	TCC2.CTRLA = TC2_CLKSEL_DIV256_gc; /* System Clock / 256 */

	return 0;
}