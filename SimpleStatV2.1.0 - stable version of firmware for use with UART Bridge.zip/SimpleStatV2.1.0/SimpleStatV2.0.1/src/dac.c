/**
 * \file
 *
 * \brief DAC related functionality implementation.
 *
 (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms,you may use this software and
    any derivatives exclusively with Microchip products.It is your responsibility
    to comply with third party license terms applicable to your use of third party
    software (including open source software) that may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 */

/**
 * \addtogroup doc_driver_dac
 *
 * \section doc_driver_dac_rev Revision History
 * - v0.0.0.1 Initial Commit
 *
 *@{
 */
#include <dac.h>

/**
 * \brief Initialize dac interface
 *
 * \return Initialization status.
 */
int8_t DAC_0_init()
{

	DACB.CTRLA = 0 << DAC_IDOEN_bp     /* Internal Output Enable: disabled */
	             | 0 << DAC_CH1EN_bp   /* Channel 1 Output Enable: disabled */
	             | 1 << DAC_CH0EN_bp   /* Channel 0 Output Enable: enabled */
	             | 0 << DAC_LPMODE_bp  /* Low Power Mode: disabled */
	             | 1 << DAC_ENABLE_bp; /* DAC Enable: enabled */

	// DACB.CTRLB = DAC_CHSEL_SINGLE_gc /* Single channel operation (Channel 0 only) */
	//		 | 0 << DAC_CH1TRIG_bp /* Channel 1 Event Trig Enable: disabled */
	//		 | 0 << DAC_CH0TRIG_bp; /* Channel 0 Event Trig Enable: disabled */

	DACB.CTRLC = DAC_REFSEL_AREFB_gc    /* External reference on AREF on PORTB */
	             | 0 << DAC_LEFTADJ_bp; /* Left-adjust Result: disabled */

	// DACB.EVCTRL = 0 << DAC_EVSPLIT_bp /* Separate Event Channel Input for Channel 1: disabled */
	//		 | DAC_EVSEL_0_gc; /* Event Channel 0 */

	/**
	 * \Initialize of DAC channel 0
	 */

	// DACB.CH0GAINCAL = 0x0 << DAC_CH0GAINCAL_gp; /* Gain Calibration: 0x0 */

	// DACB.CH0OFFSETCAL = 0x0 << DAC_CH0OFFSETCAL_gp; /* Offset Calibration: 0x0 */

	// DACB.CH0DATA = 0x0; /* Channel 0 Data: 0x0 */

	/**
	 * \Initialize of DAC channel 1
	 */

	// DACB.CH1GAINCAL = 0x0 << DAC_CH1GAINCAL_gp; /* Gain Calibration: 0x0 */

	// DACB.CH1OFFSETCAL = 0x0 << DAC_CH1OFFSETCAL_gp; /* Offset Calibration: 0x0 */

	// DACB.CH1DATA = 0x0; /* Channel 1 Data: 0x0 */

	return 0;
}

void DAC_0_set_output(dac_resolution_t value)
{
	DACB.CH0DATA = value;
}