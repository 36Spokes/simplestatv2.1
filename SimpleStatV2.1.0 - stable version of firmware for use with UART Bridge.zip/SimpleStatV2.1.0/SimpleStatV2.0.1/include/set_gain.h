/*
Use to control the MAX46127 in order to select the feedback resistor.  
Useful for changing the feedback value during a sweep automatically.
 */ 


#ifndef SET_GAIN_H_
#define SET_GAIN_H_

#include <atmel_start.h>

void set_gain_R1();

void set_gain_R2();

void set_gain_R3();

void set_gain_R4();

void set_gain_R5();

void set_gain_R6();

void set_gain_R7();

void set_gain_R8();

void gain();

#endif 