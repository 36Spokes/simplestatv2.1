/*
 EC_measurement.h
Contains the functions that perform DPV, LSV and CV electrochemical measurements.
 */ 


#ifndef EC_MEASUREMENT_H_
#define EC_MEASUREMENT_H_


uint16_t ADC_average_conversion(adc_0_channel_t channel); //Creates an average of the results based upon 20 ADC conversions

void DPV_Sweep(); //Parameters for sweep are taken via USART from PC

void LSV_sweep_up(uint8_t REF_HIGH, uint8_t REF_LOW, uint16_t MS_PER_STEP);

void LSV_sweep_down(uint8_t REF_HIGH, uint8_t REF_LOW, uint16_t MS_PER_STEP);

void LSV_sweep(); //Parameters for sweep are taken via USART from PC

void CV_sweep(); //Parameters for sweep are taken via USART from PC

void connect_cell();

void disconnect_cell();

void calibration(); //Runs a calibration routine to capture DAC output for zero point and also max/min potential

#endif /* EC_MEASUREMENT_H_ */