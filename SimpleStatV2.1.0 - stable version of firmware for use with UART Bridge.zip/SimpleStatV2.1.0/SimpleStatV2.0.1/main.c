#include <atmel_start.h>
#include <util/delay.h>
#include <stdio.h> //required for printf function
#include <avr/interrupt.h>
#include <atomic.h>
//#include <avr/cpufunc.h>
#include "EC_measurement.h"
#include "set_gain.h"


//Parameters used across several files within the code.

#define THRESHOLD 60				//ADC units for the net current that indicates a positive sample - once this value is exceeded, LED on board lights up.
#define CAL_MODE 0x63				//Represents calibration mode (ASCII Character: lower case c)
#define DPV_MODE 0x64				//Represents DPV measurement mode (ASCII Character: lower case d)
#define LSV_MODE 0x6c				//Represents LSV measurement mode (ASCII Character: lower case l)
#define CV_MODE	 0x76				//Represents CV measurement mode (ASCII Character: lower case v)
#define PRECON_MODE	0x70			//Represents Preconditioning mode (ASCII Character: lower case p)
#define GAIN_SELECT 0x67			//Represents Gain selection mode (ASCII Character: lower case g)
#define HELP 0x68					//Represents the help function (ASCII Character: lower case h)

#define NEW_LINE 0x0A				//Represents new line character in ASCII (\n)

#define CONDITIONING_POT 48			//DAC value of conditioning potential - will depend upon cell calibration
#define CONDITIONING_TIME 30000		//Length of time conditioning takes place for in ms.

#define NEXT_STEP 0x2B				// Represents signal to move to the next calibration step (ASCII Character: +)

#define DEFAULT_SIGNAL 0x00			//The signal used to control the running of the program, commands are communicated through this signal, which is then changed back to NULL here (ASCII character: null)


#define _NOP() __asm__ __volatile__("nop") //   Execute a <i>no operation</i> (NOP) CPU instruction.  This
											//should not be used to implement delays, better use the functions
											//from <util/delay_basic.h> or <util/delay.h> for this.  For
											//debugging purposes, a NOP can be useful to have an instruction that
											//is guaranteed to be not optimized away by the compiler, so it can
											//always become a breakpoint in the debugger.

bool dataReceived = false;						// Define global control signal here to allow the ISR to be used as interrupt during measurements etc.

/* Sets the gain for the TIA, must be implemented every time the gain needs to be changed.  Default gain is max current range (ie. R1 470 Ohms).*/

void serialNum(){
	printByte(SIGNATURE_0);
	printByte(SIGNATURE_1);
	printByte(SIGNATURE_2);
		
}

//Interrupt service routine - operates when the USART Rx data buffer receives a character.
//The behaviour of the SimpleStat depends upon the character pressed when under PC control.
ISR(USARTC0_RXC_vect){
	dataReceived = true;  //set flag to show that data has been read.
	
}


//Main routine used when SimpleStat is under PC control.
int main(void)
{

	
	uint8_t readData;
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	ENABLE_INTERRUPTS();
	DAC_0_set_output(2048);
	dataReceived = false;
	disconnect_cell();

	printString("\nWelcome to SimpleStat v2.0.x\nPress:\n g to set gain\n d for DPV\n l for LSV\n v for CV\n c for calibration.\n h for device signature. \n");
	
	while(1){

		while (dataReceived != true)
		{ TEST_PA7_set_level(true);}			//non operation added here in order to avoid the while loop being optimized away.
		
		readData = receiveByte();
			dataReceived = false;
			
		if(readData == DPV_MODE){
			DPV_Sweep();	//Perform electrochemical test.
		}

		else if (readData == LSV_MODE)
		{
			LSV_sweep();
		}
		else if (readData == CV_MODE)
		{
			CV_sweep();
		}
		else if(readData==CAL_MODE)
		{
			calibration();
		}
		else if (readData == GAIN_SELECT)
		{
			gain();
		}
		else if(readData == HELP){

			serialNum();
}
	printString("\nWelcome to SimpleStat v2.0.x\nPress:\n g to set gain\n d for DPV\n l for LSV\n v for CV\n c for calibration.\n h for device signature. \n");
		
	}
}